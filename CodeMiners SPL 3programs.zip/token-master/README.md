# CodeMiners - Motoko Project

## Group Members

1. **Nishant Acharekar** - 801363902  
2. **Mihir Phatak** - 801358341  
3. **Shubham Kakade** - 801413848  
4. **Calvin Pinto** - 801320115  
5. **Deepiga Sengottuvelu Ravichandran** - 801370629  
6. **Sandesh Mahajan** - 801366489  

---

## Project Overview

This project contains three Motoko programs that demonstrate:
1. **Program 1**: Data types and built-in methods.
2. **Program 2**: Data structures and control structures.
3. **Program 3**: Exception handling.

---

## Step-by-Step Guide to Run the Programs

### **Step 1: Install Prerequisites**

#### 1. **Install Node.js**:
   - Download and install Node.js from [nodejs.org](https://nodejs.org/).
   - Verify installation:
     ```bash
     node -v
     npm -v
     ```

#### 2. **Install DFX (Internet Computer SDK)**:
   - Run the following command in your terminal:
     ```bash
     sh -ci "$(curl -fsSL https://internetcomputer.org/install.sh)"
     ```
   - Verify installation:
     ```bash
     dfx --version
     ```

#### 3. **Install VSCode**:
   - Download and install Visual Studio Code from [code.visualstudio.com](https://code.visualstudio.com/).

#### 4. **Install Motoko Plugin for VSCode**:
   - Open VSCode.
   - Go to the Extensions Marketplace (Ctrl+Shift+X).
   - Search for "Motoko" and install the official Motoko plugin by DFINITY.

---

### **Step 2: Set Up the Project**

1. **Download the Project**:
   - Download the `token` folder (provided as a zip file).
   - Extract the folder to your desired location.

2. **Open the Project in VSCode**:
   - Open VSCode.
   - Click `File > Open Folder` and select the `token` folder.

3. **Verify the Folder Structure**:

   ```bash
   token/
   ├── src/
   │   ├── token/
   │   │   ├── program1.mo  # Program 1
   │   │   ├── program2.mo  # Program 2
   │   │   ├── program3.mo  # Program 3
   ├── dfx.json  # Configuration file
   ├── README.md  # This file
   ```

---

### **Step 3: Start the Local Replica**

1. Open a terminal in VSCode (`Ctrl + ~`).
2. Navigate to the `token` folder:
   ```bash
   cd path/to/token
   ```
3. Start the local Internet Computer replica:
   ```bash
   dfx start
   ```
   - **Keep this terminal open and running.**

---

### **Step 4: Deploy the Canisters**

1. Open a **new terminal** in VSCode.
2. Navigate to the `token` folder (if not already there):
   ```bash
   cd path/to/token
   ```
3. Deploy all canisters:
   ```bash
   dfx deploy
   ```
   - This will deploy `program1`, `program2`, and `program3`.

---

### **Step 5: Run the Programs**

#### **Program 1: Data Types**
```bash
dfx canister call token showcaseDataTypes
```

#### **Program 2: Data Structures**
```bash
dfx canister call program2 showcaseDataStructures
```

#### **Program 3: Exception Handling**

- **Test valid division**
  ```bash
  dfx canister call program3 divideNumbers '(5.0, 2.0)'
  ```
- **Test division by zero**
  ```bash
  dfx canister call program3 divideNumbers '(5.0, 0.0)'
  ```

---

### **Step 6: Stop the Replica**
When you’re done, stop the local replica by pressing `Ctrl + C` in the terminal where `dfx start` is running.

---

## 🔧 Troubleshooting

### 1. **Port Conflicts**
If the default port (4943) is occupied, start the replica on a different port:
```bash
dfx start --port 8001
```

### 2. **Canister Not Found**
Ensure the canister names in `dfx.json` match the names used in the `dfx canister call` commands.

### 3. **Syntax Errors**
Double-check the code in `program1.mo`, `program2.mo`, and `program3.mo` for typos.

### 4. **Reset Environment**
If you encounter issues, reset the environment:
```bash
dfx clean
dfx deploy
```

---

## Conclusion

This project demonstrates the use of **Motoko** to implement:
- Data types and built-in functions
- Data structures and control structures
- Exception handling

Follow the steps above to run the programs and explore the code. For any questions, contact the **CodeMiners** team.

---

## Auto-Generated Documentation by Motoko

The below was auto-created by Motoko, but the above steps provide a **basic understanding** of the setup and execution.

---

# `token`

Welcome to your new `token` project and to the **Internet Computer** development community. By default, creating a new project adds this README and some template files to your project directory. You can edit these template files to customize your project and to include your own code to speed up the development cycle.

To learn more before you start working with `token`, see the following documentation available online:
- [Quick Start](https://internetcomputer.org/docs/current/developer-docs/setup/deploy-locally)
- [SDK Developer Tools](https://internetcomputer.org/docs/current/developer-docs/setup/install)
- [Motoko Programming Language Guide](https://internetcomputer.org/docs/current/motoko/main/motoko)
- [Motoko Language Quick Reference](https://internetcomputer.org/docs/current/motoko/main/language-manual)

If you want to start working on your project right away, you might want to try the following commands:

```bash
cd token/
dfx help
dfx canister --help
```

## Running the project locally

To test your project locally, run:
```bash
dfx start --background
dfx deploy
```
Once the job completes, your application will be available at:
```bash
http://localhost:4943?canisterId={asset_canister_id}
```

If you have made changes to your backend canister, generate a new candid interface:
```bash
npm run generate
```

For frontend development:
```bash
npm start
```
This will start a server at `http://localhost:8080`, proxying API requests to the replica at port `4943`.

---

## Note on Frontend Environment Variables
If hosting frontend code outside `DFX`, update `process.env.DFX_NETWORK` or set:
```bash
DFX_NETWORK=ic
```

---

### 🚀 Happy Coding with Motoko & CodeMiners! 🚀

